/*
Name : Vivek Bharat Patil
Date : 09/12/2024
Description : Pick to Light Client(Part)
*/
#include <xc.h>
#include "main.h"
#include "digital_keypad.h"
#include "ssd_display.h"
#include "external_interrupt.h"
#include "isr.h"
#include "eeprom.h"
#include "can.h"

unsigned char wake=0,flag=0;                            // Initalisation of the variables
unsigned char PID[4];                                   // password to compare 
unsigned char RX_flag,swap_flag=1; 
unsigned char enter_flag=0;
unsigned char key,call=0,i,j,k,l,a,b,c,d,U_flag=1,PID_flag=1,interrupt_flag;
unsigned char w,x,y,z;
static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
static unsigned char ssd[MAX_SSD_CNT];

void write_internal_eeprom(unsigned char address, unsigned char data) 
{
	//Write the address
	EEADR = address;

	//Write the data
	EEDATA = data;

	//Point to data memory
	EECON1bits.EEPGD = 0;

	//Access data EEPROM memory
	EECON1bits.CFGS = 0;

	//Data write enable bit
	EECON1bits.WREN = 1;

	//Global interrupt disable 
	GIE = 0;

	//Write protection sequence
	EECON2 = 0x55;
	EECON2 = 0xAA;

	//Initiate write
	EECON1bits.WR = 1;

	//Global interrupt enable
	GIE = 1;

	//Wait till write is complete
	while (!PIR2bits.EEIF);

	//Disable the flag
	PIR2bits.EEIF = 0;
}

unsigned char read_internal_eeprom(unsigned char address)
{
	//Write the address, from where data has to be read
	EEADR = address;

	//Inhibits write cycles to Flash program/data EEPROM
	EECON1bits.WREN = 0;

	//Point to data memory
	EECON1bits.EEPGD = 0;

	//Access data EEPROM memory
	EECON1bits.CFGS = 0;
	
	//Initiate read
	EECON1bits.RD = 1;

	//Data available in EEDATA register
	return EEDATA;
}

void U_ST()                                       // Updated stock fun called
{
    if(key == SWITCH1 && RX_flag==0)              // when the data of Updated stock is received from the server RX_flag=1 else it is 0
    {
        if(U_flag==1)
        {
            if(i++==9)
                i=0;
        }
        else if(U_flag==2)
        {
            if(j++==9)
                j=0;
        }
        else if(U_flag==3)
        {
            if(k++==9)
                k=0;
        }
        else if(U_flag==4)
        {
            if(l++==9)
                l=0;
        }
    }
    else if(key == SWITCH1 && RX_flag)
    {
        if(w++==9)
        {
            w=0;
            if(x++==9)
            {
                x=0;
                if(y++==9)
                {
                    y=0;
                    if(z++==9)
                    {
                        z=0;
                    }
                }
            }
        }
    }
    else if(key == SWITCH2 && RX_flag==0)                  // changing the field
    {
        if(U_flag++==4)
            U_flag=1;
    }
    else if(key == SWITCH2 && RX_flag)
    {
        if(w--==0)
        {
            w=9;
            if(x--==0)
            {
                x=9;
                if(y--==0)
                {
                    y=9;
                    if(z--==0)
                    {
                        z=9;
                    }
                }
            }
        }
    }
    else if(key == SWITCH3)                                // For saving the stock value in the internal eeprom and send the data to the server
    {
        if(RX_flag)
        {
            i=w;
            j=x;
            k=y;
            l=z;
            write_internal_eeprom(0x00, i);
            write_internal_eeprom(0x01, j);
            write_internal_eeprom(0x02, k);           // writing the data to the internal eeprom when the data is get updated from the Server 
            write_internal_eeprom(0x03, l);
        }
        else
        {
            write_internal_eeprom(0x00, i);
            write_internal_eeprom(0x01, j);
            write_internal_eeprom(0x02, k);             // writing the data to the internal eeprom
            write_internal_eeprom(0x03, l);
        }
        can_transmit();
        wake=0;
        call=0;
        flag=0;
        U_flag=1;
        enter_flag=0;
        RX_flag=0;
        swap_flag=1;
    }
    
    if(RX_flag)
    {
        ssd[0]=digit[z];
        ssd[1]=digit[y];
        ssd[2]=digit[x];
        ssd[3]=digit[w];
    }
    
    if(interrupt_flag==1)                                     // when interrupt occur the SSD will go to the sleep mode
    {
        ssd[0]=0x00;
        ssd[1]=0x00;
        ssd[2]=0x00;
        ssd[3]=0x00;
    }
    else if(U_flag==1)
    {
        ssd[0]=digit[l];
        ssd[1]=digit[k];
        ssd[2]=digit[j];
        ssd[3]=digit[i] | 0x10;
    }
    else if(U_flag==2)
    {
            ssd[0]=digit[l];
            ssd[1]=digit[k];
            ssd[2]=digit[j] | 0x10;;
            ssd[3]=digit[i];
    }
    else if(U_flag==3)
    {
            ssd[0]=digit[l];
            ssd[1]=digit[k] | 0x10;;
            ssd[2]=digit[j];
            ssd[3]=digit[i];
    }
    else if(U_flag==4)
    {
        ssd[0]=digit[l] | 0x10;;
        ssd[1]=digit[k];
        ssd[2]=digit[j];
        ssd[3]=digit[i];
    }
}


void P_ID()                                           // product ID fun called
{
    if(key == SWITCH1)                     // Increamenting the value 
    {
        if(PID_flag==1)
        {
            if(a++==9)
                a=0;
        }
        else if(PID_flag==2)
        {
            if(b++==9)
                b=0;
        }
        else if(PID_flag==3)
        {
            if(c++==9)
                c=0;
        }
        else if(PID_flag==4)
        {
            if(d++==9)
                d=0;
        }
    }
    else if(key == SWITCH2 )                  // For changing the field of the SSD
    {
        if(PID_flag++==4)
            PID_flag=1;
    }
    else if(key == SWITCH3)                    // Save the Product id to the internal eeprom
    {
        write_internal_eeprom(0x05, a);
        write_internal_eeprom(0x06, b);
        write_internal_eeprom(0x07, c);
        write_internal_eeprom(0x08, d);
        PID[0]=d;
        PID[1]=c;
        PID[2]=b;                                // Product id is store in the array later checking as a password 
        PID[3]=a;
        wake=0;
        call=0;
        flag=0;
        PID_flag=1;
        enter_flag=0;
    }
    
    if(interrupt_flag==1)                         // when interrupt occur the SSD will go to the sleep mode
    {
        ssd[0]=0x00;
        ssd[1]=0x00;
        ssd[2]=0x00;
        ssd[3]=0x00;
    }
    else if(PID_flag==1)
    {
        ssd[0]=digit[d];
        ssd[1]=digit[c];
        ssd[2]=digit[b];
        ssd[3]=digit[a] | 0x10;
    }
    else if(PID_flag==2)
    {
            ssd[0]=digit[d];
            ssd[1]=digit[c];
            ssd[2]=digit[b] | 0x10;;
            ssd[3]=digit[a];
    }
    else if(PID_flag==3)
    {
            ssd[0]=digit[d];
            ssd[1]=digit[c] | 0x10;;
            ssd[2]=digit[b];
            ssd[3]=digit[a];
    }
    else if(PID_flag==4)
    {
        ssd[0]=digit[d] | 0x10;;
        ssd[1]=digit[c];
        ssd[2]=digit[b];
        ssd[3]=digit[a];
    }
}

static void init_config(void)
{
	ADCON1 = 0x0F;
	init_digital_keypad();
    init_ssd_control();
    init_can();
    PEIE= 1;
    init_external_interrupt();
    GIE = 1;
    // FOR Updated Stock Number
    i = read_internal_eeprom(0x00);
    j = read_internal_eeprom(0x01);
    k = read_internal_eeprom(0x02);                 // Reading the Updated stock for the internal eeprom
    l = read_internal_eeprom(0x03);
    
    // FOR Product ID
    a = read_internal_eeprom(0x05);
    b = read_internal_eeprom(0x06);                 // Reading the Product ID for the internal eeprom
    c = read_internal_eeprom(0x07);
    d = read_internal_eeprom(0x08);
    
    PID[0]=d;
    PID[1]=c;
    PID[2]=b;
    PID[3]=a;
}

void main(void)
{
	init_config();
    int n;
	while (1)
	{
		key = read_digital_keypad(EDGE);                        
        if(can_receive())                                  // receiving of the data and comparing the id with the PID[] array if matched it is display on the SSD 
        {                                                  //  if not then it will not be displayed
            for(n=0; n<4; n++)
            {
                if((can_payload[n+D0]-48)!=PID[n])
                {
                    break;
                }
                
            }
            if(n==4)
            {   
                z=can_payload[D4]-48;
                y=can_payload[D5]-48;
                x=can_payload[D6]-48;                     // Updated Data send by the Server
                w=can_payload[D7]-48;
                
                wake=1;
                enter_flag=1;
                RX_flag=1;
                call=1;
                U_flag=0;
                swap_flag=0;
            }
        }
        else
        {
            if(key == SWITCH3 && call==0)                       // for the changing the field    
            {
                flag=!flag;
            }
            else if(key == SWITCH2 && call==0 )                 // For entering onto the Specific function   
            {
                call=1;
                key=0;
                if(flag==0)
                    enter_flag=1;
                else if(flag==1)
                    enter_flag=2;
            }
            if(enter_flag==1)                              
            {
                U_ST();
            }
            else if(enter_flag==2)
            {
                P_ID();
            }

            if(wake && flag==0 && enter_flag==0)
            {
                ssd[0]=0xE5;
                ssd[1]=0x08;
                ssd[2]=0x6E;
                ssd[3]=0xCC;
            }
            else if(wake && flag && enter_flag==0)
            {
                ssd[0]=0x8F;
                ssd[1]=0x08;
                ssd[2]=0x21;
                ssd[3]=0xE9;
            }
            else if(enter_flag==0)
            {
                ssd[0]=0x00;
                ssd[1]=0x00;
                ssd[2]=0x00;
                ssd[3]=0x00;
            }
        }
        display(ssd);
        
	}
}



